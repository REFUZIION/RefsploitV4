Welcome you are one of the lucky early access users of REFSPLOIT.

Everything is ready and set to be used. If you want to add your own scripts to the scripthub
add them into the folder called ScriptHub. If your scripts don't show up in the scripthub
try to press the refresh button.



!!KEEP IN MIND THAT LEAKING THIS VERSION WILL RESULT IN A PERMANENT 
BAN AND TERMINATION OF YOUR CURRENT REFSPLOIT APPLICATION!!

Happy exploiting!

- REFUZIION
Lead developer for REFSPLOIT